TRIMUI Smart timezone set for network time
===============================================
This folder includes all timezone set files.
Copy your city named timezone file to SD card root, renamed 'timezone'
For example in china:
copy Asia/Shanghai to root, rename file 'Shanghai' to 'timezone'


Example SD card contents:
    Apps
    Emus
    System
    Imgs
    RetroArch
    RetroArch_sdl
    Roms
    Saves
    Themes
    timezone  <--- copy here
